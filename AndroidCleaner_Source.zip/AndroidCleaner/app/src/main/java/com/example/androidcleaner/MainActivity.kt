package com.example.androidcleaner

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.usage.StorageStatsManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.DocumentsContract
import android.provider.Settings
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.ArrayDeque
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var scanButton: Button
    private var selectedTree: Uri? = null
    private val largeFiles = mutableListOf<FileItem>()
    private val documentPicker = 1001

    data class FileItem(val uri: Uri, val name: String, val size: Long, val mime: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshStats()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(28))
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        addText("清理助手", 28f, 0xFF172033.toInt(), true, 0, 2)
        addText("本地分析 · 不上传数据 · 删除前确认", 14f, 0xFF5E6B82.toInt(), false, 0, 18)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(card, matchWrap())
        val title = TextView(this).apply {
            text = "设备概况"
            textSize = 18f
            setTextColor(0xFF172033.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        card.addView(title)
        statusText = TextView(this).apply {
            text = "正在读取设备信息…"
            textSize = 15f
            setTextColor(0xFF354158.toInt())
            setPadding(0, dp(10), 0, dp(8))
        }
        card.addView(statusText)
        addButtonTo(card, "刷新设备数据") { refreshStats() }

        addSection("清理与优化")
        addInfoCard("1. 大文件扫描", "选择一个你有权限访问的文件夹，列出其中较大的文件。仅扫描你选定的目录。")
        scanButton = addButton("选择文件夹并扫描大文件") { chooseFolder() }
        root.addView(scanButton, matchWrap())
        addButton("查看扫描结果 / 删除选中文件") { showLargeFiles() }

        addInfoCard("2. 系统存储清理", "跳转到安卓系统设置，由系统显示缓存和应用占用。应用不能安全地静默清除其他应用的私有缓存。")
        addButton("打开系统存储设置") {
            openSettings(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS), Intent(Settings.ACTION_SETTINGS))
        }

        addInfoCard("3. 后台与运行状态", "查看系统内存概况，并进入系统应用管理页面自行限制不需要的后台活动。此工具不会强制结束应用。")
        addButton("打开应用管理") {
            openSettings(Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS), Intent(Settings.ACTION_SETTINGS))
        }
        addButton("查看电池 / 后台管理") {
            openSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS), Intent(Settings.ACTION_SETTINGS))
        }

        addSection("安全说明")
        addText("• 不需要联网权限，不会上传文件或设备数据。", 14f, 0xFF354158.toInt(), false, 0, 4)
        addText("• 扫描只覆盖你主动选择并授权的文件夹。", 14f, 0xFF354158.toInt(), false, 0, 4)
        addText("• 删除操作会再次确认；删除后可能无法恢复。请勿删除不认识的文件。", 14f, 0xFF354158.toInt(), false, 0, 4)
        addText("• 不承诺“加速百分比”或虚构清理量；实际效果以系统显示为准。", 14f, 0xFF354158.toInt(), false, 0, 4)
        addText("版本 1.0 · Android 8.0 及以上 · 离线运行", 12f, 0xFF7A8497.toInt(), false, 0, 0)
    }

    private fun refreshStats() {
        try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            val total = stat.totalBytes
            val available = stat.availableBytes
            val used = (total - available).coerceAtLeast(0)
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            statusText.text = "内部存储已用：${fmt(used)} / ${fmt(total)}\n" +
                "可用空间：${fmt(available)}\n" +
                "系统报告的可用运行内存：${fmt(mi.availMem)}\n" +
                "低内存状态：${if (mi.lowMemory) "是" else "否"}\n\n" +
                "提示：运行内存数据是系统快照，不代表可以通过“清理”永久增加性能。"
        } catch (e: Exception) {
            statusText.text = "无法读取部分设备信息。请使用下方系统设置查看存储状态。"
        }
    }

    private fun chooseFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, documentPicker)
    }

    @Deprecated("Deprecated in Android SDK, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == documentPicker && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            selectedTree = uri
            val flags = (data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION))
            try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) {}
            scanButton.isEnabled = false
            scanButton.text = "正在扫描所选文件夹…"
            thread {
                val results = scanTree(uri)
                runOnUiThread {
                    largeFiles.clear()
                    largeFiles.addAll(results.sortedByDescending { it.size }.take(100))
                    scanButton.isEnabled = true
                    scanButton.text = "重新选择文件夹并扫描"
                    Toast.makeText(this, "扫描完成：找到 ${largeFiles.size} 个较大文件（最多显示 100 个）", Toast.LENGTH_LONG).show()
                    showLargeFiles()
                }
            }
        }
    }

    private fun scanTree(treeUri: Uri): List<FileItem> {
        val output = mutableListOf<FileItem>()
        val queue = ArrayDeque<Uri>()
        try {
            val rootId = DocumentsContract.getTreeDocumentId(treeUri)
            queue.add(DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId))
            var visited = 0
            while (queue.isNotEmpty() && visited < 12000) {
                val parent = queue.removeFirst()
                visited++
                val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
                    treeUri, DocumentsContract.getDocumentId(parent)
                )
                val projection = arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_SIZE,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
                )
                contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                    val idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                    val nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                    val sizeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
                    val mimeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
                    while (cursor.moveToNext()) {
                        val id = cursor.getString(idCol) ?: continue
                        val name = cursor.getString(nameCol) ?: "未命名文件"
                        val mime = if (mimeCol >= 0) cursor.getString(mimeCol) ?: "" else ""
                        val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            queue.add(docUri)
                        } else {
                            val size = if (sizeCol >= 0 && !cursor.isNull(sizeCol)) cursor.getLong(sizeCol) else 0L
                            if (size >= 20L * 1024L * 1024L) {
                                output.add(FileItem(docUri, name, size, mime))
                            }
                        }
                    }
                }
            }
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
        return output
    }

    private fun showLargeFiles() {
        if (largeFiles.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("扫描结果")
                .setMessage(if (selectedTree == null) "还没有扫描文件夹。请先选择一个你有权限访问的文件夹。" else "未找到大于等于 20 MB 的文件，或所选目录无法读取。")
                .setPositiveButton("知道了", null).show()
            return
        }
        val labels = largeFiles.map { "${it.name}\n${fmt(it.size)}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("大文件列表（点选后确认删除）")
            .setItems(labels) { _, which -> confirmDelete(largeFiles[which]) }
            .setNegativeButton("关闭", null)
            .setNeutralButton("重新扫描") { _, _ -> selectedTree?.let { uri ->
                thread {
                    val results = scanTree(uri)
                    runOnUiThread {
                        largeFiles.clear()
                        largeFiles.addAll(results.sortedByDescending { it.size }.take(100))
                        showLargeFiles()
                    }
                }
            } }
            .show()
    }

    private fun confirmDelete(file: FileItem) {
        AlertDialog.Builder(this)
            .setTitle("确认删除？")
            .setMessage("文件：${file.name}\n大小：${fmt(file.size)}\n\n删除可能无法恢复。请确认这是你不再需要的文件。")
            .setNegativeButton("取消", null)
            .setPositiveButton("删除文件") { _, _ ->
                thread {
                    val ok = try { DocumentsContract.deleteDocument(contentResolver, file.uri) } catch (_: Exception) { false }
                    runOnUiThread {
                        Toast.makeText(this, if (ok) "已请求系统删除该文件" else "删除失败：系统可能不允许删除此文件", Toast.LENGTH_LONG).show()
                        if (ok) largeFiles.remove(file)
                        showLargeFiles()
                        refreshStats()
                    }
                }
            }.show()
    }

    private fun openSettings(primary: Intent, fallback: Intent) {
        try { startActivity(primary) } catch (_: Exception) {
            try { startActivity(fallback) } catch (_: Exception) {
                Toast.makeText(this, "无法打开系统设置，请从手机设置中手动进入。", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun addSection(text: String) {
        addText(text, 19f, 0xFF172033.toInt(), true, 0, 8)
    }

    private fun addInfoCard(title: String, body: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val t = TextView(this).apply {
            text = title; textSize = 16f; setTextColor(0xFF172033.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val b = TextView(this).apply {
            text = body; textSize = 13f; setTextColor(0xFF5E6B82.toInt())
            setPadding(0, dp(6), 0, 0)
        }
        card.addView(t); card.addView(b)
        val p = LinearLayout.LayoutParams(-1, -2)
        p.topMargin = dp(8); p.bottomMargin = dp(4)
        root.addView(card, p)
    }

    private fun addButton(text: String, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 14f
            setOnClickListener { action() }
            val p = LinearLayout.LayoutParams(-1, -2)
            p.topMargin = dp(4); p.bottomMargin = dp(4)
            layoutParams = p
        }
    }

    private fun addButtonTo(parent: LinearLayout, text: String, action: () -> Unit) {
        parent.addView(addButton(text, action), matchWrap())
    }

    private fun addText(text: String, size: Float, color: Int, bold: Boolean, top: Int, bottom: Int) {
        val view = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            if (top > 0 || bottom > 0) setPadding(0, dp(top), 0, dp(bottom))
        }
        root.addView(view, matchWrap())
    }

    private fun fmt(bytes: Long): String = Formatter.formatFileSize(this, bytes)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
}
